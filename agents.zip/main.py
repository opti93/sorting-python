end_list = open('result.txt','w')
listdir = open('passive.txt')
order_set = set(open('active.txt').readlines())

for line in listdir.readlines():
   if line not in order_set:
       end_list.write(line)